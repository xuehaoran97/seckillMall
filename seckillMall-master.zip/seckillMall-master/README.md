# seckillMall

github本地项目与远程项目建立联系
https://www.cnblogs.com/smallpen/p/9538073.html


github token生成方法
https://cloud.tencent.com/developer/article/1861466
我的token

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
