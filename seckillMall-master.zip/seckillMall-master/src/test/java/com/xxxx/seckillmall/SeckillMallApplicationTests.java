package com.xxxx.seckillmall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeckillMallApplicationTests {

    @Test
    void contextLoads() {
    }

}
