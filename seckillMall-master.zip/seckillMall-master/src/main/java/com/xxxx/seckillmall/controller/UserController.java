package com.xxxx.seckillmall.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author haoranXue
 * @since 2021-12-02
 */
@Controller
@RequestMapping("/user")
public class UserController {

}
