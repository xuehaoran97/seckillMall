package com.xxxx.seckillmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xxxx.seckillmall.pojo.User;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author haoranXue
 * @since 2021-12-02
 */
public interface UserMapper extends BaseMapper<User> {

}
